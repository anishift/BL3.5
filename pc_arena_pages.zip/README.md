# Borderlands‑ish: PC Arena (GitHub Pages)

Publicera:
1) Skapa ett publikt repo, t.ex. `pc-arena`.
2) Ladda upp `index.html` och `.nojekyll` till repo-root.
3) Settings → Pages → Source: Deploy from a branch, Branch: main, Folder: /(root) → Save.

Länk blir: `https://<användarnamn>.github.io/<repo>/`
